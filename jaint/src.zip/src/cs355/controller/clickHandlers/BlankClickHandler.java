package cs355.controller.clickHandlers;

import java.awt.geom.Point2D.Double;

import cs355.controller.TheController;

public class BlankClickHandler extends ClickHandler {

	public BlankClickHandler(TheController c) {
		super(c);
	}

	@Override
	public void mouseDragged(Double wLoc) {
	}

	@Override
	public void mouseMoved(Double wLoc) {
	}

	@Override
	public void mouseClicked(Double wLoc) {
	}

	@Override
	public void mousePressed(Double wLoc) {
	}

	@Override
	public void mouseReleased(Double wLoc) {
	}

	@Override
	public void clean() {
	}

}
